const Product = require('.././models/product.model');

// Create a new product
const createProduct = async (req, res) => {
  const { name, description, price, quantity, category } = req.body;

  try {
    const newProduct = new Product({ name, description, price, quantity, category });
    const savedProduct = await newProduct.save();

    res.status(201).json(savedProduct);
  } catch (error) {
    console.error('Error creating product:', error);
    res.status(500).json({ error: 'Failed to create the product.' });
  }
};

// Get all products
const getAllProducts = async (req, res) => {
  try {
    const products = await Product.find();
    res.status(200).json(products);
  } catch (error) {
    console.error('Error fetching products:', error);
    res.status(500).json({ error: 'Failed to fetch products.' });
  }
};

// Get product by ID
const getProductById = async (req, res) => {
  const productId = req.params.id;

  try {
    const product = await Product.findById(productId);
    if (!product) {
      return res.status(404).json({ error: 'Product not found.' });
    }
    res.status(200).json(product);
  } catch (error) {
    console.error('Error fetching product by ID:', error);
    res.status(500).json({ error: 'Failed to fetch product.' });
  }
};

// Find products by name containing 'kw'
const findProducts = async (req, res) => {
  const keyword = 'kw';

  try {
    const products = await Product.find({ name: { $regex: keyword, $options: 'i' } });
    res.status(200).json(products);
  } catch (error) {
    console.error('Error finding products:', error);
    res.status(500).json({ error: 'Failed to find products.' });
  }
};

// Update product by ID
const updateProductById = async (req, res) => {
  const productId = req.params.id;
  const updateData = req.body;

  try {
    const updatedProduct = await Product.findByIdAndUpdate(productId, updateData, { new: true });
    if (!updatedProduct) {
      return res.status(404).json({ error: 'Product not found.' });
    }
    res.status(200).json(updatedProduct);
  } catch (error) {
    console.error('Error updating product by ID:', error);
    res.status(500).json({ error: 'Failed to update product.' });
  }
};

// Remove product by ID
const removeProductById = async (req, res) => {
  const productId = req.params.id;

  try {
    const deletedProduct = await Product.findByIdAndRemove(productId);
    if (!deletedProduct) {
      return res.status(404).json({ error: 'Product not found.' });
    }
    res.status(204).send();
  } catch (error) {
    console.error('Error removing product by ID:', error);
    res.status(500).json({ error: 'Failed to remove product.' });
  }
};

// Remove all products
const removeAllProducts = async (req, res) => {
  try {
    await Product.deleteMany({});
    res.status(204).send();
  } catch (error) {
    console.error('Error removing all products:', error);
    res.status(500).json({ error: 'Failed to remove all products.' });
  }
};

module.exports = {
  createProduct,
  getAllProducts,
  getProductById,
  findProducts,
  updateProductById,
  removeProductById,
  removeAllProducts,
};
