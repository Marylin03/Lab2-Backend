router.post('/api/product', createProduct);
router.get('/api/product', getAllProducts);
router.get('/api/product/:id', getProductById);
router.get('/api/product/search', findProducts);
router.put('/api/product/:id', updateProductById);
router.delete('/api/product/:id', removeProductById);
router.delete('/api/product', removeAllProducts);

module.exports = router;
